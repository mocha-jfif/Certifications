# The Seven-Layer Model

1. Physical
2. Data Link
3. Network
4. Transport
5. Session
6. Presentation
7. Application

## Physical Layer
- Identifies hardware and network topology.
- USB, Ethernet, Bluetooth, DSL, ISDN, etc., run here.
- Defines voltage, frequency, speed/distance, and bandwidth.

## Data Link Layer
- Responsible for data transfer to the physical layer, error detection / correction, and hardware addressing.
- A [[frame]] describes the logical grouping of data at this layer.
- Two sublayers:
	- Media Access Control (MAC) layer: Address is burned into the NIC; controls access to network media. 
		- Defined in IEEE 802.2.
	- Logical Link Control (LLC) layer: Error and flow control mechanisms.
- Protocols: HDLC, L2TP, PPP, PPTP, STP, VLANs.

## Network Layer
- Responsible for routing.
- Provides mechanisms to pass data and route selection. 
	- Routing protocols are software components.
	- Contains IP headers.
	- Utilizes [[packets]].
- Routes can be configured manually by adding them to the routing table (static) or by using RIP and DSPF (dynamic).
- [[2 Protocols & Ports#Internet Protocol|IP]], ARP, RARP, ATM, IS-IS, [[2 Protocols & Ports#Internet Protocol Security|IPSec]], [[2 Protocols & Ports#Internet Control Message Protocol|ICMP]], MPLS

## Transport Layer
- Responsible for mechanisms to transport data in three ways:
	- Error checking
	- Service addressing
	- Segmentation
- Also responsible for data flow control using two common methods:
	- Buffering
	- Windowing

## Session Layer
- Responsible for managing and controlling the synchronization of data between applications on two devices; establishes, maintains, and breaks sessions.
- Performs the same essential functions as the transport layer, but on behalf of the applications.
- NetBIOS, NFS, [[2 Protocols & Ports#Server Message Block|SMB]].

## Presentation Layer
- Responsible for converting data to appropriate formats.
- Also responsible for encryption; TLS runs here.

## Application Layer
- Responsible for taking requests / data and passing it to other layers.
- Information is displayed here.
- Not the applications themselves, but the protocols that allow network capabilities.
- [[2 Protocols & Ports#Secure Shell|SSH]], BGP, [[2 Protocols & Ports#Dynamic Host Configuration Protocol|DHCP]], [[2 Protocols & Ports#Domain Name System|DNS]], NTP, RTP, [[2 Protocols & Ports#Session Initiation Protocol|SIP]], [[2 Protocols & Ports#Simple Mail Transfer Protocol|SMTP]], SNB, FTP, HTTP/S, IMAP, POP3


# OSI Versus TCP/IP

![[Blank board(1).png]]

# Data En/Decapsulation and OSI
- As data moves down the model, it is encapsulated with a header and trailer.
- Once received and moving back up the model, these are stripped off. 