# Unicast
- Traffic is one-to-one.
- Most common in IP networks.
- Point-to-point, one-to-one address link.

# Multicast
- Groups of network devices can send and receive data between the members of the group at one time. (One-to-many).
- Grouping is established by configuring each device with the same multicast IP address.
- Commonly used for IPTV, gaming, and video streaming.

# Anycast
- Traffic is one-to-nearest.
- Multiple devices share the same anycast IP address, but packets are routed to the nearest (or best) destination based on routing metrics such as shortest path or lowest latency.
- Commonly used in CDNs, DNS, and load balancers.

# Broadcast
- Traffic is one-to-all.
- Each packet is addressed to a specical broadcast IP address.
- Commonly used in Arp, DHCP, and network discovery.
- Does not propagate across routers.

