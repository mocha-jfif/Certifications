>[!faq] A grouping of information transmitted as a unit across the network at the data link layer of the OSI model.
