>[!faq] A unit of data that travels in communication networks.
>
