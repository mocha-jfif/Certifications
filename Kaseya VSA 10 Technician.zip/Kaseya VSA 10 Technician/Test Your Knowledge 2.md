Once we have upgraded to VSA 10, I will be deploying Agents on our customers' systems. How can I do this?
1. ==Network Discovery and Deployment==
2. Scopes

At which level can VSA 10's Patch Management policies be applied?
1. ==Organization, Site, or Agent Group level==
2. Agent Group level only

When viewing a topology map in VSA 10, upon hovering over any device, ==summary== information about the device will be displayed.

When applying Ransomware Detection to your systems, please have the following in placE:
1. ==A ransomware detection policy==
2. ==A ransomware detection license==
3. A ransomware detection workflow rule

True or false: Notifications can be configured when new devices are added to a network.
1. ==True==
2. False

