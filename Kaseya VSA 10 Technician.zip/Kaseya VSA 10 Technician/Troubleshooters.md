The Client Portal allows you to build multiple interactive resolution troubleshooters using an intuitive visual editor.

These are workflows that can trigger tasks and scripts based on user responses to predefined questions. This allows you to define multiple standards, resolution paths to reflect users, and individual circumstances to create a troubleshooter.

The client portal allows you to build multiple interactive resolution troubleshooters using an intuitive visual editor. These are effective workflows that can trigger tasks and scripts based on user responses to pre-defined questions. 

This allows you to define multiple standard resolution paths to reflect the user’s individual circumstances.

Once you have enrolled end users into the client portal, they can easily access it using just their email address. If their computer has the VSA 10 agent installed, you can choose to link to the portal from the system tray. 

Users simply click on the relevant troubleshooter, and it immediately runs. You can also brand the portal with your own logo.

These can be used:
- To effectively resolve common tasks without assistance from a technician
- To find a fast and effective resolution to a well-detailed issue
- When end-users request new hardware that can bypass the Support queue