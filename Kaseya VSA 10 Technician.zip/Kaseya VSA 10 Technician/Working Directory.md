**_This directory is created automatically by the VSA 10 agent and will act as your temporary folder_**

Path:
- Windows: C:\ProgramData\Kaseya\VSAX\Working 
    
- Mac: Currently not available 
    
- Linux: Currently not available

Workflow actions that support this feature:
- Execute File 
    
- Write File 
    
- Get URL 
    
- Unzip File 
    
- Delete File

