## Agent
The VSA 10 Agent is a lightweight software program installed on a device to monitor and gather up-to-date information about the device's health and status, then communicates it to the platform.


## Patch
A patch is a set of changes to a computer program or its supporting data designed to update, fix, or improve it.

## Patch Management
VSA 10 Patch Management allows you to both control and automate the deployment of Windows patches to your devices.

## Policy
The vehicle for applying configuration settings.

## Tags
Tags can help organize IT estates in a more granular format. Systems can be tagged by location, role, customer name, etc.

