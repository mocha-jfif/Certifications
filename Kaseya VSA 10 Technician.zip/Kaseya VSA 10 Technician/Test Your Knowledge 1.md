
What grouping structure is used in VSA 10 to group systems?
1. ==**Agent Groups**==
2. Machine groups

What are the following areas called in VSA 10: Anti-Malware and Agent Procedures?
1. ==**Sections**==
2. Modules

Connecting to a system via ==**remote control**== allows you to take control of the endpoint as if you were positioned in front of it.

What information can be viewed from dashboards?
1. ==**Status of managed endpoints**==
2. ==**Active alerts**==
3. ==**Important alerts**==

When using the VSA 10 mobile application, you *can't* perform the same functions that are found in the web application.
1. True
2. ==**False==**





